=== Progressive WordPress ===
Contributors: nico_martin
Donate link: https://www.paypal.me/NicoMartin
Tags: Performance, Pagespeed, scriptloading, optimize, http2, server push, SPDY, preload, Critical CSS, Critical CSS API
Requires at least: 4.7
Tested up to: 4.9.1
Stable tag: 0.0.1
Requires PHP: 5.4
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

This plugin adds progressive features to your WordPress site and turns it into a Progressive Web App.

== Screenshots ==

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory or install it from the plugin directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done

== Frequently Asked Questions ==

= No questions yet =

There are no at the moment. Please use the support forum. I'll update this section as soon as there are actually some FAQs.

== Contribute ==

A development version of this plugin is hosted on github. If you have some ideas for improvements, feel free to dive into the code:
[https://github.com/nico-martin/Advanced-WPPerformance](https://github.com/nico-martin/progressive-wordpress)

== Changelog ==

= 0.0.1 =
* Initial version.
