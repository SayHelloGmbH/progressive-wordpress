<?php

require_once dirname( __FILE__ ) . '/src/Minify.php';
require_once dirname( __FILE__ ) . '/src/CSS.php';
require_once dirname( __FILE__ ) . '/src/JS.php';
require_once dirname( __FILE__ ) . '/src/Exception.php';
require_once dirname( __FILE__ ) . '/src/Exceptions/BasicException.php';
require_once dirname( __FILE__ ) . '/src/Exceptions/FileImportException.php';
require_once dirname( __FILE__ ) . '/src/Exceptions/IOException.php';
